var app = angular.module('myApp', ['ngFileSaver']);

app.controller('myController', ['$scope', 'FileSaver', 'Blob', function ($scope, FileSaver, Blob) {    
    
    $scope.download = function () { // Download the parsed invoice numbers
        
        var data = new Blob([$scope.output], {
            type: 'text/plain;charset=utf-8'
        });
        
        FileSaver.saveAs(data, 'parsedInvoices.txt', true);
    };
}]);
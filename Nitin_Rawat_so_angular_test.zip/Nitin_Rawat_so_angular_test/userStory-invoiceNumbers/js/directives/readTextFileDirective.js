app.directive('readTextFileDirective', ['helperService', function (helperService) {
    console.log('dir');
    return {
        restrict: 'A',
        scope: {
            input: '=',
            output: '='
        },
        link: function (scope, elem, attrs) {
            if (!window.FileReader) {
                return;
            }
            elem.on('change', function (changeEvent) {
                var reader = new FileReader();
                reader.readAsText((changeEvent.srcElement || changeEvent.target).files[0]);
                reader.onload = function (loadEvent) {
                    scope.input = loadEvent.target.result; // Text input from attached file
                    scope.output = helperService.getParsedInvoices(scope.input); // Parsed numbers string from helper service    
                    scope.$apply();
                }
            });
        }
    }
  }]);
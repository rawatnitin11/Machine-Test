app.factory('helperService',function(){
    
    var indexCheckArr = [[0,2,4], [0,1,2,3,4,6,7], [0,2,3,8], [0,2,3,6], [0,1,2,6,7], [0,2,5,6], [0,2,5], [0,2,3,4,6,7], [0,2],     [0,2,6]]; // Array having all the indexes of blank characters in 7 segment for number 0 to 9. For example: For number 0, indexes 0, 2 and 6 are blank spaces.
    
    var indexesOf = function (string) { // function returns all the indexes where blank space is found
                    var match,
                    indexes = [];
                    var regex = new RegExp(/ /g);
                    while (match = regex.exec(string)) {
                        indexes.push(match.index);
                    }
                    return indexes;
                }
    
    var factoryObject = {};
    
    factoryObject.getParsedInvoices = function (input) {
        
        var linesArray = input.split('\n'); // split the 7 segment by '\n' to get an array of lines.
        
        var outputString = "",
            count = 0;
        
        for (var i = 0; i < linesArray.length;i = i+4) { //Iterate over all the 3 lines in the 9 digit invoice number. 4 is added after each loop, as the ASCII numbers are formed by 3 lines and 4th lines is blank after each invoice number.
            
            var line1Arr = linesArray[i]; // all characters(| and _) from line 1 of 7 segment 9 digit invoice number
            var line2Arr = linesArray[i+1]; // all characters from line 2
            var line3Arr = linesArray[i+2]; // all characters from line 3
            
            for (var j = 0;j < line1Arr.length;j = j+3) {
                
                var charString = line1Arr.substr(j,3)+line2Arr.substr(j,3)+line3Arr.substr(j,3); //string of characters in a number from line1 + line2 + line 3
                var blankIndexes = indexesOf(charString); // get all the blank space indexes in current character string
                
                for (var k = 0; k < indexCheckArr.length; k++) {
                    if (angular.equals(blankIndexes, indexCheckArr[k])) {
                        outputString += k;
                        break;
                    }                    
                }
                count++;                
                if (count && count%9 === 0) {
                    outputString += "\r\n";
                }
            }
        }
        return outputString;
    }
    
    return factoryObject;
    
});

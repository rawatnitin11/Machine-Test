# Parse Invoice Numbers  

## Overview

This AngularJs application allows the user to upload a text file of 7-segment invoice numbers, and outputs a list with the parsed invoice numbers. 7-segment invoice numbers are formed by combining 3 lines of the text file and the output is one parsed invoice number per line.

### How to run  

Unzip userStroy-invoiceNumbers folder to your local machine and run index.html file.  







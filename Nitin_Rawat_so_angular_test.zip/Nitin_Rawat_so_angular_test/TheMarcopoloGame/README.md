# The Marco Polo Game  

## Overview

The Marcopolo game is developed to iterate over numbers from 0 to 100 and replace with "marco" when the number is divisible by 4. Every time the number is divisible by 7, the number is replaced by 'polo'. If the number is divisible by both 4 and 7, the number is replaced by 'marcopolo'.

### How to run  

Unzip TheMarcopoloGame folder to your local machine and run index.html file.  



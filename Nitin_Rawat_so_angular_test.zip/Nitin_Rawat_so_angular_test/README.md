# Simple Angular 1.x Question

##How can you limit the scope on a directive and why would you do this?
Scope on a directive can be limited to just its own scope by setting the scope property in the directive definition object to either true or an empty object.  

###1. scope: true

Directive will inherit scope but will not have any dependency on the parent scope (i.e. controller in most cases).  

For Example  

    app.directive ('myDirective' , function () {  
        return {
            scope: True,
            template: '<p>This is inherited scope</p>',
            controller: function ($scope) {
            }
        };
    });


###2. scope: {}
Directive will have its own scope and will not inherit scope from the parent. But some properties can be shared with the parent scope by using '@' string binding, '=' data binding and '&' method binding.

For Example  

    app.directive ('myDirective' , function () {  
        return {
            scope: {},
            template: '<p>This is isolate scope</p>',
            controller: function ($scope) {
            }
        };
    });

By default a directive shares whatever scope is defined above it. But, in most of the scenarios, when we do not want to share the scope from outside to directive or vice-versa then we make create directive's scope. This prevents the one scope from polluting the other scope. For example, if the directive expected a scope property to be undefined but it actually had an inherited value, it could cause unexpected issues. Limiting the scope also creates independent components which can be reused without any dependencies on the parent scope.